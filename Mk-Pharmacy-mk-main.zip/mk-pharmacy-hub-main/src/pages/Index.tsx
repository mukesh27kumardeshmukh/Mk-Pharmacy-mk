import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Microscope, Pill, Dna, BookOpen, Youtube, Send, Sparkles } from "lucide-react";
import heroImage from "@/assets/hero-pharmacy.jpg";
import logo from "@/assets/logo.jpg";

const Index = () => {
  const features = [
    {
      icon: <Microscope className="w-10 h-10" />,
      title: "🔬 Science की रोचक जानकारी",
      description: "विज्ञान की दुनिया से जुड़ी रोमांचक और ज़रूरी जानकारियाँ सीधे आपके लिए"
    },
    {
      icon: <Pill className="w-10 h-10" />,
      title: "💊 दवा और Health",
      description: "दवाइयों और स्वास्थ्य से जुड़ी आसान और समझने लायक जानकारी"
    },
    {
      icon: <Dna className="w-10 h-10" />,
      title: "🧬 Biology Concepts",
      description: "जीव विज्ञान के शानदार कॉन्सेप्ट्स और एक्सप्लेनर वीडियोस"
    },
    {
      icon: <BookOpen className="w-10 h-10" />,
      title: "📚 शिक्षा और ज्ञान",
      description: "शिक्षा और सीखने से संबंधित उपयोगी और व्यावहारिक ज्ञान"
    }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-accent to-background" />
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-gradient-to-br from-primary/10 via-transparent to-transparent blur-3xl animate-float" />
        <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-gradient-to-tr from-secondary/10 via-transparent to-transparent blur-3xl animate-float" style={{ animationDelay: "1s" }} />
      </div>

      {/* Header with Logo */}
      <header className="bg-background/60 backdrop-blur-xl border-b border-border/50 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 group">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-full blur-xl group-hover:blur-2xl transition-all duration-300" />
                <img 
                  src={logo} 
                  alt="Mk Pharmacy Logo" 
                  className="relative w-20 h-20 object-contain hover:scale-110 transition-transform duration-500 drop-shadow-lg" 
                />
              </div>
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  Mk Pharmacy
                </h2>
                <p className="text-sm text-muted-foreground">Science & Health Education</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button 
                size="sm" 
                variant="outline"
                className="border-primary/30 hover:border-primary hover:bg-primary/5 transition-all duration-300"
                onClick={() => window.open('https://t.me/Mk_Pharmacy', '_blank')}
              >
                <Send className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">Telegram</span>
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                className="border-secondary/30 hover:border-secondary hover:bg-secondary/5 transition-all duration-300"
                onClick={() => window.open('https://youtube.com/@mk_pharmacy?si=KH9y8SDeaTYyeDeQ', '_blank')}
              >
                <Youtube className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">YouTube</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="space-y-8 animate-fade-in">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-primary/10 to-secondary/10 text-primary px-5 py-2.5 rounded-full text-sm font-semibold border border-primary/20 shadow-lg">
                <Sparkles className="w-4 h-4" />
                Welcome to Mk Pharmacy
              </div>
              <h1 className="text-5xl md:text-7xl font-bold leading-tight">
                <span className="text-foreground">विज्ञान और</span>
                <br />
                <span className="text-foreground">स्वास्थ्य की</span>
                <br />
                <span className="bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent animate-gradient">
                  पूर्ण जानकारी
                </span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Science, Medicine, Biology और Education से जुड़ी आसान और रोचक जानकारी के लिए हमारे साथ जुड़ें।
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  size="lg" 
                  className="group relative overflow-hidden bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-primary-foreground shadow-2xl hover:shadow-primary/30 transition-all duration-300 text-base"
                  onClick={() => window.open('https://t.me/Mk_Pharmacy', '_blank')}
                >
                  <span className="relative z-10 flex items-center">
                    <Send className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                    Join Telegram Channel
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-secondary to-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="group border-2 border-secondary/50 text-secondary hover:bg-secondary hover:text-secondary-foreground hover:border-secondary shadow-lg hover:shadow-secondary/30 transition-all duration-300 text-base"
                  onClick={() => window.open('https://youtube.com/@mk_pharmacy?si=KH9y8SDeaTYyeDeQ', '_blank')}
                >
                  <Youtube className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform duration-300" />
                  YouTube Channel
                </Button>
              </div>
              <div className="flex items-center gap-8 text-sm text-muted-foreground pt-6">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-secondary rounded-full animate-pulse shadow-lg shadow-secondary/50" />
                  <span className="font-medium">Regular Updates</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-primary rounded-full animate-pulse shadow-lg shadow-primary/50" />
                  <span className="font-medium">Free Content</span>
                </div>
              </div>
            </div>
            <div className="relative animate-slide-up" style={{ animationDelay: "0.2s" }}>
              <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-secondary/30 rounded-3xl blur-3xl animate-pulse" />
              <div className="relative rounded-3xl overflow-hidden shadow-2xl ring-1 ring-border/50">
                <img 
                  src={heroImage} 
                  alt="Mk Pharmacy - Science and Health Education" 
                  className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            हम क्या प्रदान करते हैं?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            विज्ञान और स्वास्थ्य की दुनिया से जुड़ी हर जानकारी एक जगह
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="group relative overflow-hidden hover:shadow-2xl transition-all duration-500 border-border/50 hover:border-primary/50 bg-gradient-to-br from-card to-card/50 backdrop-blur-sm animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <CardHeader className="relative">
                <div className="text-primary mb-4 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                  {feature.icon}
                </div>
                <CardTitle className="text-xl text-card-foreground group-hover:text-primary transition-colors duration-300">
                  {feature.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="relative">
                <CardDescription className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <Card className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-secondary/5 to-primary/5 border-primary/20 shadow-2xl backdrop-blur-sm">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-secondary/10" />
          <CardContent className="relative p-10 md:p-16 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-primary to-secondary mb-6 shadow-lg">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              आज ही जुड़ें हमारे साथ!
            </h2>
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              Science, Medicine और Education की latest जानकारी पाने के लिए अभी हमारे Telegram Channel और YouTube को Subscribe करें।
            </p>
            <div className="flex flex-col sm:flex-row gap-5 justify-center">
              <Button 
                size="lg" 
                className="group relative overflow-hidden bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-primary-foreground shadow-2xl hover:shadow-primary/40 transition-all duration-300 text-lg px-10 py-6"
                onClick={() => window.open('https://t.me/Mk_Pharmacy', '_blank')}
              >
                <span className="relative z-10 flex items-center">
                  <Send className="w-6 h-6 mr-2 group-hover:rotate-12 transition-transform duration-300" />
                  @Mk_Pharmacy पर जुड़ें
                </span>
              </Button>
              <Button 
                size="lg" 
                className="group relative overflow-hidden bg-gradient-to-r from-secondary to-secondary/90 hover:from-secondary/90 hover:to-secondary text-secondary-foreground shadow-2xl hover:shadow-secondary/40 transition-all duration-300 text-lg px-10 py-6"
                onClick={() => window.open('https://youtube.com/@mk_pharmacy?si=KH9y8SDeaTYyeDeQ', '_blank')}
              >
                <span className="relative z-10 flex items-center">
                  <Youtube className="w-6 h-6 mr-2 group-hover:scale-110 transition-transform duration-300" />
                  YouTube Subscribe करें
                </span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="relative bg-card/50 backdrop-blur-sm border-t border-border/50 py-10">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground text-base mb-4">
            © 2025 Mk Pharmacy. All rights reserved. | विज्ञान और स्वास्थ्य की जानकारी का विश्वसनीय स्रोत
          </p>
          <div className="flex justify-center gap-8 mt-6">
            <a 
              href="https://t.me/Mk_Pharmacy" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group text-muted-foreground hover:text-primary transition-all duration-300"
            >
              <div className="p-3 rounded-full border border-border hover:border-primary hover:bg-primary/5 transition-all duration-300">
                <Send className="w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
              </div>
            </a>
            <a 
              href="https://youtube.com/@mk_pharmacy?si=KH9y8SDeaTYyeDeQ" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group text-muted-foreground hover:text-secondary transition-all duration-300"
            >
              <div className="p-3 rounded-full border border-border hover:border-secondary hover:bg-secondary/5 transition-all duration-300">
                <Youtube className="w-6 h-6 group-hover:scale-110 transition-transform duration-300" />
              </div>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
